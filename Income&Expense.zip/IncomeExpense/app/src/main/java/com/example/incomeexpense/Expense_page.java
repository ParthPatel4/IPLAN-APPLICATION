package com.example.incomeexpense;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class Expense_page extends AppCompatActivity {

    public ImageButton ExpensePagePrevious;
    private EditText ExpenseData;
    private EditText HousingAmount;
    private EditText TransportationAmount;
    private EditText FoodAmount;
    private EditText PersonalCareAmount;
    private EditText ShoppingAmount;
    private EditText HealthCareAmount;
    private TextView TotalExpense;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_page);
        ExpensePagePrevious = findViewById(R.id.image_ExpenseGoBack);
        ExpenseData = findViewById(R.id.editText_ExpenseDate);
        HousingAmount = findViewById(R.id.editText_HousingAmount);
        TransportationAmount = findViewById(R.id.editText_TransportationAmount);
        FoodAmount = findViewById(R.id.editText_FoodAmount);
        PersonalCareAmount = findViewById(R.id.editText_PersonalCareAmount);
        ShoppingAmount = findViewById(R.id.editText_ShoppingAmount);
        HealthCareAmount = findViewById(R.id.editText_HealthCareAmount);
        TotalExpense = findViewById(R.id.textView_ExpenseTotalIncome);


        ExpensePagePrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Expense_page.this, MainActivity.class));
            }
        });
    }

    public void calculatorClick(View view){
        String HousingAmountStr = HousingAmount.getText().toString();
        String TransportationAmountStr = TransportationAmount.getText().toString();
        String FoodAmountStr = FoodAmount.getText().toString();
        String PersonalAmountStr = PersonalCareAmount.getText().toString();
        String ShoppingAmountStr = ShoppingAmount.getText().toString();
        String HealthCareAmountStr = HealthCareAmount.getText().toString();

        int numHousing, numT, numF, numP, numS, numHealth;
        try{
            numHousing = Integer.parseInt(HousingAmountStr);
            numT = Integer.parseInt(TransportationAmountStr);
            numF = Integer.parseInt(FoodAmountStr);
            numP = Integer.parseInt(PersonalAmountStr);
            numS = Integer.parseInt(ShoppingAmountStr);
            numHealth = Integer.parseInt(HealthCareAmountStr);

        } catch (NumberFormatException ex) {
            numHousing = 0;
            numT = 0;
            numF = 0;
            numP = 0;
            numS = 0;
            numHealth = 0;
        }

        int sumIncome = (int)Math.ceil(numHousing+numT+numF+numP+numS+numHealth);
        TotalExpense.setText("Total Expense: " + sumIncome);
    }
}