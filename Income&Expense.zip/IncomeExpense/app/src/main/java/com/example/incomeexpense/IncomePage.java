package com.example.incomeexpense;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class IncomePage extends AppCompatActivity {

    public ImageButton IncomePagePrevious;
    private EditText IncomeData;
    private EditText SalaryAmount;
    private EditText InvestAmount;
    private EditText OtherAmount;
    private TextView TotalIncome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_income_page);
        IncomePagePrevious = findViewById(R.id.image_IncomeGoBack);
        IncomeData = findViewById(R.id.editTextIncome_Data);
        SalaryAmount = findViewById(R.id.editText_SalaryAmount);
        InvestAmount = findViewById(R.id.editText_InvestAmount);
        OtherAmount = findViewById(R.id.editText_OtherAmount);
        TotalIncome = findViewById(R.id.textView_TotalIncome);

        IncomePagePrevious.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {

                startActivity(new Intent(IncomePage.this, MainActivity.class));
            }
        });
    }

    public void calculatorClick(View view){
        String SalaryAmountStr = SalaryAmount.getText().toString();
        String InvestAmountStr = InvestAmount.getText().toString();
        String OtherAmountStr = OtherAmount.getText().toString();

        int numS, numI, numO;
        try{
            numS = Integer.parseInt(SalaryAmountStr);
            numI = Integer.parseInt(InvestAmountStr);
            numO = Integer.parseInt(OtherAmountStr);
        } catch (NumberFormatException ex) {
            numS = 0;
            numI = 0;
            numO = 0;
        }

        int sumIncome = (int)Math.ceil(numS+numI+numO);
        TotalIncome.setText("Total Income: " + sumIncome);
    }


}

