package com.example.tips;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import java.util.List;

public class TipsListFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_tips_list, container, false);
        LinearLayout layout = (LinearLayout) view;

        //Read the list of Tips list and add the button to each element
        List<Tips> tipsList = TipsDatabase.getInstance(getContext()).getTips();
        for(int i=0; i<tipsList.size(); i++){
            Button button = new Button(getContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(0,0,0,10);
            button.setLayoutParams(layoutParams);

            //Get information for button
            Tips tips = TipsDatabase.getInstance(getContext()).getTip(i+1);
            button.setText(tips.getName());
            button.setTag(Integer.toString(tips.getId()));

            button.setOnClickListener(buttonClickListener);
            layout.addView(button);
        }
        return view;
    }

    private View.OnClickListener buttonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            //Send the tips id of the click button to details activity
            //And it can show the details of that specific tip that we click
            Intent intent = new Intent(getActivity(), DetailsActivity.class);
            String tipId = (String) view.getTag();
            intent.putExtra(DetailsActivity.EXTRA_TIP_ID, Integer.parseInt((tipId)));
            startActivity(intent);
        }
    };
}