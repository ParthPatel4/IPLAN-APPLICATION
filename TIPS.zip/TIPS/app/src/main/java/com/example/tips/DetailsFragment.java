package com.example.tips;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class DetailsFragment extends Fragment {

    private Tips mTips;

    public static DetailsFragment newInstance(int tipId){
        DetailsFragment fragment = new DetailsFragment();
        Bundle args = new Bundle();
        args.putInt("tipId", tipId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int tipId = 1;
        if(getArguments() != null){
            tipId = getArguments().getInt("tipId");
        }
        mTips = TipsDatabase.getInstance(getContext()).getTip(tipId);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_details_activity, container, false);
        //Get the tip/description name and set to the text view
        TextView nameTextView = view.findViewById(R.id.TipTitle);
        nameTextView.setText(mTips.getName());

        TextView descriptionTextView = (TextView)view.findViewById(R.id.TipDescription);
        descriptionTextView.setText(mTips.getDescription());

        return view;
    }
}