package com.example.tips;

// TIps object class
public class Tips {
    private int mId;
    private String mName;
    private String mDescription;

    public Tips(){}

    public Tips(int id, String name, String description){
        mId = id;
        mName = name;
        mDescription = description;
    }

    public void setId(int id){
        this.mId = id;
    }
    public int getId(){
        return mId;
    }

    public void setName(String name){
        this.mName = name;
    }
    public String getName(){
        return mName;
    }

    public void setDescription(String Description){ this.mDescription = Description;}
    public String getDescription(){ return mDescription;}

}
