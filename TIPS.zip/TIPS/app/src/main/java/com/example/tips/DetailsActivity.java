package com.example.tips;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

public class DetailsActivity extends AppCompatActivity {

    public static final String EXTRA_TIP_ID = "TipId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.details_fragment_container);

        if(fragment == null){

            int tipId = getIntent().getIntExtra(EXTRA_TIP_ID, 1);
            fragment = DetailsFragment.newInstance(tipId);

            fragment = new DetailsFragment();
            fragmentManager.beginTransaction().add(R.id.details_fragment_container,fragment).commit();
        }
    }
}