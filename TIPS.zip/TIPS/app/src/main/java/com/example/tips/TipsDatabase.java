package com.example.tips;

import android.content.Context;
import android.content.res.Resources;

import java.util.List;
import java.util.ArrayList;

public class TipsDatabase {

    private static TipsDatabase sTipsDatabase;
    private List<Tips> mTips;

    public static TipsDatabase getInstance(Context context){
        if(sTipsDatabase == null){
            sTipsDatabase =  new TipsDatabase(context);
        }
        return sTipsDatabase;
    }

    //The database with tips which reads the text file
    private TipsDatabase(Context context){
        mTips = new ArrayList<>();
        Resources res = context.getResources();
        String [] tips = res.getStringArray(R.array.tips);
        String [] descriptions = res.getStringArray(R.array.descriptions);
        // Add and store the information to the tips list
        for (int i = 0; i < tips.length; i++){
            mTips.add(new Tips(i+1, tips[i], descriptions[i]));
        }
    }
    //Get the tips
    public List<Tips> getTips(){ return mTips;}
    public Tips getTip(int tipID){
        for (Tips tips : mTips){
            if(tips.getId() == tipID){
                return tips;
            }
        }
        return null;
    }
}
